package com.example.campusapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ReportDetailActivity extends AppCompatActivity {

    TextView txtReportType, txtReportLocation, txtReportDescription, txtReportStatus;
    Button btnMarkResolved, btnDeleteReport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_detail);

        txtReportType = findViewById(R.id.txtReportType);
        txtReportLocation = findViewById(R.id.txtReportLocation);
        txtReportDescription = findViewById(R.id.txtReportDescription);
        txtReportStatus = findViewById(R.id.txtReportStatus);
        btnMarkResolved = findViewById(R.id.btnMarkResolved);
        btnDeleteReport = findViewById(R.id.btnDeleteReport);

        btnMarkResolved.setOnClickListener(v -> markResolved());

        btnDeleteReport.setOnClickListener(v -> {
            Toast.makeText(ReportDetailActivity.this, "Report deleted", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    private void markResolved() {
        txtReportStatus.setText("Resolved");
        Toast.makeText(this, "Report marked as resolved", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_report_detail, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_mark_resolved) {
            markResolved();
            return true;
        } else if (id == R.id.action_delete_report) {
            Toast.makeText(this, "Report deleted", Toast.LENGTH_SHORT).show();
            finish();
            return true;
        } else if (id == R.id.action_home) {
            startActivity(new Intent(this, MainActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

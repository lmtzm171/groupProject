package com.example.campusapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.ReportViewHolder> {

    private ArrayList<Report> reportList;

    public ReportAdapter(ArrayList<Report> reportList) {
        this.reportList = reportList;
    }

    @NonNull
    @Override
    public ReportViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_report, parent, false);
        return new ReportViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReportViewHolder holder, int position) {
        Report report = reportList.get(position);
        holder.txtReportTitle.setText(report.getType() + " - " + report.getLocation());
        holder.txtReportDesc.setText(report.getDescription());
    }

    @Override
    public int getItemCount() {
        return reportList.size();
    }

    public static class ReportViewHolder extends RecyclerView.ViewHolder {
        TextView txtReportTitle, txtReportDesc;

        public ReportViewHolder(@NonNull View itemView) {
            super(itemView);
            txtReportTitle = itemView.findViewById(R.id.txtReportTitle);
            txtReportDesc = itemView.findViewById(R.id.txtReportDesc);
        }
    }
}

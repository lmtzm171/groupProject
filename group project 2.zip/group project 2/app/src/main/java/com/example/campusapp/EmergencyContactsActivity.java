package com.example.campusapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EmergencyContactsActivity extends AppCompatActivity {

    Button btnCallCampusPolice, btnCall911, btnSafetyTips;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency_contacts);

        btnCallCampusPolice = findViewById(R.id.btnCallCampusPolice);
        btnCall911 = findViewById(R.id.btnCall911);
        btnSafetyTips = findViewById(R.id.btnSafetyTips);

        btnCallCampusPolice.setOnClickListener(v ->
                Toast.makeText(EmergencyContactsActivity.this,
                        "Calling Campus Police...",
                        Toast.LENGTH_SHORT).show());

        btnCall911.setOnClickListener(v ->
                Toast.makeText(EmergencyContactsActivity.this,
                        "Calling 911...",
                        Toast.LENGTH_SHORT).show());

        btnSafetyTips.setOnClickListener(v -> showSafetyTip());
    }

    private void showSafetyTip() {
        Toast.makeText(this,
                "Safety Tip: Stay aware of your surroundings and report suspicious activity immediately.",
                Toast.LENGTH_LONG).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_emergency, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_safety_tip) {
            showSafetyTip();
            return true;
        } else if (id == R.id.action_new_report) {
            startActivity(new Intent(this, ReportFormActivity.class));
            return true;
        } else if (id == R.id.action_home) {
            startActivity(new Intent(this, MainActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

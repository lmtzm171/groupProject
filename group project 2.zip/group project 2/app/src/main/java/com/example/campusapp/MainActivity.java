package com.example.campusapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnNewReport, btnHistory, btnEmergency, btnDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnNewReport = findViewById(R.id.btnNewReport);
        btnHistory = findViewById(R.id.btnHistory);
        btnEmergency = findViewById(R.id.btnEmergency);
        btnDetail = findViewById(R.id.btnDetail);

        btnNewReport.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ReportFormActivity.class)));

        btnHistory.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ReportHistoryActivity.class)));

        btnEmergency.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, EmergencyContactsActivity.class)));

        btnDetail.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ReportDetailActivity.class)));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_new_report) {
            startActivity(new Intent(this, ReportFormActivity.class));
            return true;
        } else if (id == R.id.action_history) {
            startActivity(new Intent(this, ReportHistoryActivity.class));
            return true;
        } else if (id == R.id.action_emergency) {
            startActivity(new Intent(this, EmergencyContactsActivity.class));
            return true;
        } else if (id == R.id.action_about) {
            Toast.makeText(this, "Campus Safety App v1.0\nReport incidents and stay safe.", Toast.LENGTH_LONG).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

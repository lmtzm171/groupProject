package com.example.campusapp;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.Toast;

public class ReportService extends Service {

    @Override
    public void onCreate() {
        super.onCreate();
        Toast.makeText(this, "ReportService started", Toast.LENGTH_SHORT).show();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String type = intent.getStringExtra("type");
            String location = intent.getStringExtra("location");
            String description = intent.getStringExtra("description");

            processReport(type, location, description);
        }
        return START_NOT_STICKY;
    }

    private void processReport(String type, String location, String description) {
        Toast.makeText(this,
                "Processing report: " + type + " at " + location,
                Toast.LENGTH_SHORT).show();
        stopSelf();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Toast.makeText(this, "ReportService stopped", Toast.LENGTH_SHORT).show();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

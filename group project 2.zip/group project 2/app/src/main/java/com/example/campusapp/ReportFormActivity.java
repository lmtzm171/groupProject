package com.example.campusapp;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ReportFormActivity extends AppCompatActivity {

    Spinner spinnerType;
    EditText etLocation, etDescription;
    Button btnSubmitReport;
    ReportSubmittedReceiver reportSubmittedReceiver;
    AirplaneModeReceiver airplaneModeReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_form);

        spinnerType = findViewById(R.id.spinnerType);
        etLocation = findViewById(R.id.etLocation);
        etDescription = findViewById(R.id.etDescription);
        btnSubmitReport = findViewById(R.id.btnSubmitReport);

        String[] reportTypes = {"Suspicious Activity", "Hazard", "Emergency", "Other"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                reportTypes
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerType.setAdapter(adapter);

        reportSubmittedReceiver = new ReportSubmittedReceiver();
        IntentFilter reportFilter = new IntentFilter(ReportSubmittedReceiver.ACTION_REPORT_SUBMITTED);
        registerReceiver(reportSubmittedReceiver, reportFilter, RECEIVER_NOT_EXPORTED);

        airplaneModeReceiver = new AirplaneModeReceiver();
        IntentFilter airplaneFilter = new IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        registerReceiver(airplaneModeReceiver, airplaneFilter, RECEIVER_EXPORTED);

        btnSubmitReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                submitReport();
            }
        });
    }

    private void submitReport() {
        String type = spinnerType.getSelectedItem().toString();
        String location = etLocation.getText().toString().trim();
        String description = etDescription.getText().toString().trim();

        if (location.isEmpty() || description.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this,
                    "Report Submitted:\n" + type + "\n" + location,
                    Toast.LENGTH_LONG).show();

            Intent serviceIntent = new Intent(this, ReportService.class);
            serviceIntent.putExtra("type", type);
            serviceIntent.putExtra("location", location);
            serviceIntent.putExtra("description", description);
            startService(serviceIntent);

            Intent broadcastIntent = new Intent(ReportSubmittedReceiver.ACTION_REPORT_SUBMITTED);
            broadcastIntent.putExtra("type", type);
            broadcastIntent.putExtra("location", location);
            sendBroadcast(broadcastIntent);

            clearForm();
        }
    }

    private void clearForm() {
        etLocation.setText("");
        etDescription.setText("");
        spinnerType.setSelection(0);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_report_form, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_clear_form) {
            clearForm();
            Toast.makeText(this, "Form cleared", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.action_home) {
            startActivity(new Intent(this, MainActivity.class));
            return true;
        } else if (id == R.id.action_history) {
            startActivity(new Intent(this, ReportHistoryActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(reportSubmittedReceiver);
        unregisterReceiver(airplaneModeReceiver);
    }
}

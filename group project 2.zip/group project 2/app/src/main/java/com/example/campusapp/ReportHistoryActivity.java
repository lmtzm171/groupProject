package com.example.campusapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ReportHistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerViewReports;
    private ReportAdapter reportAdapter;
    private ArrayList<Report> reportList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_history);

        recyclerViewReports = findViewById(R.id.recyclerViewReports);
        recyclerViewReports.setLayoutManager(new LinearLayoutManager(this));

        reportList = new ArrayList<>();
        reportList.add(new Report("Hazard", "Parking Lot", "Broken glass near the entrance"));
        reportList.add(new Report("Suspicious Activity", "Library", "Unknown person loitering near the door"));
        reportList.add(new Report("Emergency", "Dorm Hall", "Fire alarm triggered on third floor"));

        reportAdapter = new ReportAdapter(reportList);
        recyclerViewReports.setAdapter(reportAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_report_history, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_new_report) {
            startActivity(new Intent(this, ReportFormActivity.class));
            return true;
        } else if (id == R.id.action_clear_history) {
            reportList.clear();
            reportAdapter.notifyDataSetChanged();
            Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show();
            return true;
        } else if (id == R.id.action_home) {
            startActivity(new Intent(this, MainActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

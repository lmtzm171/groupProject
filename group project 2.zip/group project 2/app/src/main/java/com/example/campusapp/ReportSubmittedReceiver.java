package com.example.campusapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class ReportSubmittedReceiver extends BroadcastReceiver {

    public static final String ACTION_REPORT_SUBMITTED = "com.example.campusapp.REPORT_SUBMITTED";

    @Override
    public void onReceive(Context context, Intent intent) {
        String type = intent.getStringExtra("type");
        String location = intent.getStringExtra("location");

        Toast.makeText(context,
                "New report received: " + type + " at " + location,
                Toast.LENGTH_LONG).show();
    }
}

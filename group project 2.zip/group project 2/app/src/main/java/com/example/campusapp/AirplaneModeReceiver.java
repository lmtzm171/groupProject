package com.example.campusapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.widget.Toast;

public class AirplaneModeReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        boolean isAirplaneModeOn = Settings.System.getInt(
                context.getContentResolver(),
                Settings.Global.AIRPLANE_MODE_ON, 0) != 0;

        if (isAirplaneModeOn) {
            Toast.makeText(context, "Airplane mode is ON. Some features may be unavailable.", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(context, "Airplane mode is OFF. All features restored.", Toast.LENGTH_SHORT).show();
        }
    }
}

package com.example.campusapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ReportFormActivity extends AppCompatActivity {

    Spinner spinnerType;
    EditText etLocation, etDescription;
    Button btnSubmitReport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_form);

        spinnerType = findViewById(R.id.spinnerType);
        etLocation = findViewById(R.id.etLocation);
        etDescription = findViewById(R.id.etDescription);
        btnSubmitReport = findViewById(R.id.btnSubmitReport);

        String[] reportTypes = {"Suspicious Activity", "Hazard", "Emergency", "Other"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                reportTypes
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerType.setAdapter(adapter);

        btnSubmitReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String type = spinnerType.getSelectedItem().toString();
                String location = etLocation.getText().toString().trim();
                String description = etDescription.getText().toString().trim();

                if (location.isEmpty() || description.isEmpty()) {
                    Toast.makeText(ReportFormActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ReportFormActivity.this,
                            "Report Submitted:\n" + type + "\n" + location,
                            Toast.LENGTH_LONG).show();

                    etLocation.setText("");
                    etDescription.setText("");
                    spinnerType.setSelection(0);
                }
            }
        });
    }
}
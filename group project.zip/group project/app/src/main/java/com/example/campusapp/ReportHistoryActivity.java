package com.example.campusapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ReportHistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerViewReports;
    private ReportAdapter reportAdapter;
    private ArrayList<Report> reportList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_history);

        recyclerViewReports = findViewById(R.id.recyclerViewReports);
        recyclerViewReports.setLayoutManager(new LinearLayoutManager(this));

        reportList = new ArrayList<>();
        reportList.add(new Report("Hazard", "Parking Lot", "Broken glass near the entrance"));
        reportList.add(new Report("Suspicious Activity", "Library", "Unknown person loitering near the door"));
        reportList.add(new Report("Emergency", "Dorm Hall", "Fire alarm triggered on third floor"));

        reportAdapter = new ReportAdapter(reportList);
        recyclerViewReports.setAdapter(reportAdapter);
    }
}
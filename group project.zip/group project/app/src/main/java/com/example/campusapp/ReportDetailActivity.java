package com.example.campusapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ReportDetailActivity extends AppCompatActivity {

    TextView txtReportType, txtReportLocation, txtReportDescription, txtReportStatus;
    Button btnMarkResolved, btnDeleteReport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_detail);

        txtReportType = findViewById(R.id.txtReportType);
        txtReportLocation = findViewById(R.id.txtReportLocation);
        txtReportDescription = findViewById(R.id.txtReportDescription);
        txtReportStatus = findViewById(R.id.txtReportStatus);
        btnMarkResolved = findViewById(R.id.btnMarkResolved);
        btnDeleteReport = findViewById(R.id.btnDeleteReport);

        btnMarkResolved.setOnClickListener(v -> {
            txtReportStatus.setText("Resolved");
            Toast.makeText(ReportDetailActivity.this, "Report marked as resolved", Toast.LENGTH_SHORT).show();
        });

        btnDeleteReport.setOnClickListener(v -> {
            Toast.makeText(ReportDetailActivity.this, "Report deleted", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
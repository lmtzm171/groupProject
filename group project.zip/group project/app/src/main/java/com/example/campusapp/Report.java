package com.example.campusapp;

public class Report {
    private String type;
    private String location;
    private String description;

    public Report(String type, String location, String description) {
        this.type = type;
        this.location = location;
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public String getLocation() {
        return location;
    }

    public String getDescription() {
        return description;
    }
}

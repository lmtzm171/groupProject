package com.example.campusapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnNewReport, btnHistory, btnEmergency, btnDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnNewReport = findViewById(R.id.btnNewReport);
        btnHistory = findViewById(R.id.btnHistory);
        btnEmergency = findViewById(R.id.btnEmergency);
        btnDetail = findViewById(R.id.btnDetail);

        btnNewReport.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ReportFormActivity.class)));

        btnHistory.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ReportHistoryActivity.class)));

        btnEmergency.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, EmergencyContactsActivity.class)));

        btnDetail.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ReportDetailActivity.class)));
    }
}
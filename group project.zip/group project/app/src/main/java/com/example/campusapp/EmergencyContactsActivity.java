package com.example.campusapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EmergencyContactsActivity extends AppCompatActivity {

    Button btnCallCampusPolice, btnCall911, btnSafetyTips;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency_contacts);

        btnCallCampusPolice = findViewById(R.id.btnCallCampusPolice);
        btnCall911 = findViewById(R.id.btnCall911);
        btnSafetyTips = findViewById(R.id.btnSafetyTips);

        btnCallCampusPolice.setOnClickListener(v ->
                Toast.makeText(EmergencyContactsActivity.this,
                        "Calling Campus Police...",
                        Toast.LENGTH_SHORT).show());

        btnCall911.setOnClickListener(v ->
                Toast.makeText(EmergencyContactsActivity.this,
                        "Calling 911...",
                        Toast.LENGTH_SHORT).show());

        btnSafetyTips.setOnClickListener(v ->
                Toast.makeText(EmergencyContactsActivity.this,
                        "Safety Tip: Stay aware of your surroundings and report suspicious activity immediately.",
                        Toast.LENGTH_LONG).show());
    }
}